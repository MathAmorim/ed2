#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef enum {INT, MAIN, RETURN, ID, NUM, DESCONHECIDO, ABRE_CHAVES, FECHA_CHAVES, ABRE_PARENTESES, FECHA_PARENTESES, ESPACO, PONTO_E_VIRGULA, FIM_DE_ARQUIVO} TIPO;

typedef struct token{
	int linha;
	int coluna;
	TIPO tipo;
	union{
		int inteiro;
		char *string;
		char car;
	}valor;
}Token;


int lin=1;
int col=0;
Token token;
FILE *f, *o;

int obter_numero(FILE *f, int car){
	int num = car - '0';
			
	car = fgetc(f);
	col++;
	while(isdigit(car)){
		num = (num * 10) + car - '0';
		car = fgetc(f);
		col++;
	}
	ungetc(car, f);
	col--;
	return num;
}

void obter_id(FILE *f, char buffer[]){
	char car;
	int i=1;
	car = fgetc(f);
	col++;
	while(isalnum(car) || car == '_'){
		buffer[i++]=car;
		car = fgetc(f);
		col++;
	}
	buffer[i] = '\0';
	ungetc(car, f);
	col--;
}

Token obter_token(){
	Token token;
	char car;

	while((car = fgetc(f)) != EOF ){
		col++;

		if (car == '\n'){
			lin++;
			col=0;
			continue;
		}

		if (car == ' '){
			continue;
		}

		// Atualizando a posição de linha e coluna do token
		token.linha = lin;
		token.coluna = col;

		// reconhecendo um token abre parenteses
		if (car == '('){
			token.tipo = ABRE_PARENTESES;
			token.valor.car = car;
			return token;
		}

		// reconhecendo um token fecha parenteses
		if (car == ')'){
			token.tipo = FECHA_PARENTESES;
			token.valor.car = car;
			return token;
		}

		// reconhecendo um token abre chaves
		if (car == '{'){
			token.tipo = ABRE_CHAVES;
			token.valor.car = car;
			return token;
		}

		// reconhecendo um token fecha chaves
		if (car == '}'){
			token.tipo = FECHA_CHAVES;
			token.valor.car = car;
			return token;
		}

		// reconhecendo um token ponto e vírgula
		if (car == ';'){
			token.tipo = PONTO_E_VIRGULA;
			token.valor.car = car;
			return token;
		}

		//obter um identificador
		if (isalpha(car) || car == '_'){
			char buffer[100];
			buffer[0] = car;
			obter_id(f, buffer);

			token.valor.string = strdup(buffer);

			// reconhecendo o token MAIN
			if (!strcmp(buffer, "main")){
				token.tipo = MAIN;
				return token;
			}

			// reconhecendo o token INT
			if (!strcmp(buffer, "int")){
				token.tipo = INT;
				return token;
			}

			// reconhecendo o token RETURN
			if (!strcmp(buffer, "return")){
				token.tipo = RETURN;
				return token;
			}

			// reconhecendo um identificador
			token.tipo = ID;
			return token;
		}

		// obter um número
		if (isdigit(car)){
			int num = obter_numero(f, car);
			token.tipo = NUM;
			token.valor.inteiro = num;
			return token;
		}

		token.tipo = DESCONHECIDO;
		token.valor.car = car;
		return token;
	}

	token.tipo = FIM_DE_ARQUIVO;
	token.valor.car = car;
	return token;
}

void mostrar_token(Token token){
	switch(token.tipo){
		case NUM:
			printf("(%i, %i): <NUM, %i>\n", token.linha, token.coluna, token.valor.inteiro);
			break;

		case ID:
			printf("(%i, %i): <ID, %s>\n", token.linha, token.coluna, token.valor.string);
			break;

		case MAIN:
			printf("(%i, %i): <MAIN, %s>\n", token.linha, token.coluna, token.valor.string);
			break;

		case INT:
			printf("(%i, %i): <INT, %s>\n", token.linha, token.coluna, token.valor.string);
			break;

		case RETURN:
			printf("(%i, %i): <RETURN, %s>\n", token.linha, token.coluna, token.valor.string);
			break;

		case DESCONHECIDO:
			printf("(%i, %i): <DESCONHECIDO, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		case ABRE_PARENTESES:
			printf("(%i, %i): <ABRE_PARENTESES, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		case FECHA_PARENTESES:
			printf("(%i, %i): <FECHA_PARENTESES, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		case ABRE_CHAVES:
			printf("(%i, %i): <ABRE_CHAVES, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		case FECHA_CHAVES:
			printf("(%i, %i): <FECHA_CHAVES, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		case PONTO_E_VIRGULA:
			printf("(%i, %i): <PONTO_E_VIRGULA, %c>\n", token.linha, token.coluna, token.valor.car);
			break;

		default:
			printf("ATENÇÃO, ALGUM ERRO OCORREU AO RECONHECER TOKEN.\n");
	}
}

// PARTE DO CÓDIGO PARA GERAÇÃO
void montar_codigo_inicial(){
	o = fopen("out.s","w+");
	fprintf(o, ".text\n");
	fprintf(o, "    .global _start\n\n");
  	fprintf(o, "_start:\n\n");
}

void montar_codigo_retorno(int numero){
	fprintf(o, "    movq    $%d, %%rbx\n", numero);
	fprintf(o, "    movq    $1, %%rax\n");
	fprintf(o, "    int     $0x80\n\n");
}

void montar_codigo_final(){
	fclose(o);

	printf("Arquivo \"out.s\" gerado.\n\n");
}

// PARTE DO CÓDIGO PARA ANÁLISE SINTÁTICA
void erro(char *msg){
	printf("Erro na linha %i coluna %i, espera um token: %s\n", token.linha, token.coluna, msg);
	exit(0);
}

void corpo(){
	if (token.tipo == RETURN){
		token = obter_token();
		if (token.tipo == NUM){

			montar_codigo_retorno(token.valor.inteiro);

			token = obter_token();

			if (token.tipo == PONTO_E_VIRGULA){
				token = obter_token();

				corpo();

			}else
				erro(";");
		}else
			erro("número");
	}else{
		// não faz nada
		montar_codigo_retorno(0);
	}
}

void programa(){
	if (token.tipo == INT){
		token = obter_token();
		if (token.tipo == MAIN){
			token = obter_token();
			if (token.tipo == ABRE_PARENTESES){
				token = obter_token();
				if (token.tipo == FECHA_PARENTESES){
					token = obter_token();
					if (token.tipo == ABRE_CHAVES){
						token = obter_token();

						montar_codigo_inicial();
						
						corpo();

						if (token.tipo == FECHA_CHAVES){
							token = obter_token();

							montar_codigo_final();

						}else						
							erro("}");
					}else
						erro("{");
				}else
					erro(")");
			}else
				erro("(");
		}else
			erro("main");
	}else
		erro("int");
}


int main(int argc, char *argv[]){
	
	if (argc != 2){
		printf("Não foi informado o arquivo para compilar.\n");
		return 2;
	}

	f = fopen(argv[1], "r");

	if (f == NULL){
		printf("Falha ao abrir o arquivo: %s.\n", argv[1]);
		return 1;
	}

	token = obter_token();
	programa();
	if (token.tipo == FIM_DE_ARQUIVO){
		printf("Programa OK.\n");
	}else
		erro("fim de arquivo");	
}






